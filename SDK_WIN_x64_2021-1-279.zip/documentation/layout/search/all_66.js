var searchData=
[
  ['formattedtext_2eh',['formattedtext.h',['../formattedtext_8h.html',1,'']]]
];
