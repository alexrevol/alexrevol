var searchData=
[
  ['tx',['tx',['../struct_s_u_transformation2_d.html#aaac985987cf312d2865b894f6b22615f',1,'SUTransformation2D']]],
  ['ty',['ty',['../struct_s_u_transformation2_d.html#a1dbfdf50da2f806fb142e3a789394acf',1,'SUTransformation2D']]]
];
