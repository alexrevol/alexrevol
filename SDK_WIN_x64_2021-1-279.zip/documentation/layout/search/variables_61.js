var searchData=
[
  ['a',['a',['../struct_s_u_plane3_d.html#ac20abbfe5c53954c051f39a67e360651',1,'SUPlane3D']]],
  ['alpha',['alpha',['../struct_s_u_color.html#a77a421e57b9fcb475804ac425b337e9b',1,'SUColor']]]
];
