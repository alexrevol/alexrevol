var searchData=
[
  ['unichar',['unichar',['../_sketch_up_a_p_i_2common_8h.html#af3e9ea72fde464fc6bd2ac469fadd780',1,'common.h']]]
];
