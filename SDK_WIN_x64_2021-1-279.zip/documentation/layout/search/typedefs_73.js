var searchData=
[
  ['subyte',['SUByte',['../color_8h.html#ac0aeffa13b9b3eeb77446c843c5f6d29',1,'color.h']]]
];
